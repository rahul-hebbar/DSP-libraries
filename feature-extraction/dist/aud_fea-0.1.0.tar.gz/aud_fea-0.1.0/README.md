# Feature Extraction  

##This library can be used for audio feature extraction  

For info on how to use the package go to:  
https://github.com/rahul-hebbar/DSP-libraries/tree/master/feature-extraction


